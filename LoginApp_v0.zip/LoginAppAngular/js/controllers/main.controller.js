(function () {
    'use strict';
 
    myModule
        .controller('MainController', MainController);
 
    MainController.$inject = ['$scope', '$state', '$stateParams', 'LoginService'];
    function MainController($scope, $state, $stateParams, LoginService) {
        var vm = this;
 
        $scope.$state = $state;
	    $scope.$stateParams = $stateParams;

        vm.logout = function(){
            LoginService.ClearCredentials();
            $state.go('login');
        }
    }
 
})();