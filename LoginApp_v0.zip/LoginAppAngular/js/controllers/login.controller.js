(function () {
    'use strict';
 
    myModule
        .controller('LoginController', LoginController);
 
    LoginController.$inject = ['$state', 'LoginService'];
    function LoginController($state, LoginService) {
        var vm = this;
 
        vm.login = login;
 
        (function initController() {
            // reset login status
            LoginService.ClearCredentials();
        })();
 
        function login() {
            vm.dataLoading = true;
            LoginService.loginUser(vm.username, vm.password)
            .success(function(response) {
                
                console.log("Login sucess: " + response);
                LoginService.SetCredentials(vm.username, vm.password);
                $state.go('app.dash');

            }).error(function(response) {
                
                alert("Login error: " + response);
                vm.dataLoading = false;
            });
        };
    }
 
})();