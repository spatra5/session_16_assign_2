var myModule = angular.module("LoginApp", ["ui.router"]);

myModule.config(function($stateProvider, $urlRouterProvider) {
    
    $urlRouterProvider.otherwise('/home');
    
    $stateProvider

    // State home and multiple named views
    .state('home', {
        url: '/home',
        views: {

            // the main template will be placed here (relatively named)
            '': { templateUrl: 'partials/home.html' },
        },
        data: {
            requireLogin: false 
        }
    })
    
    
    // State login
    .state('login', {
        url: '/login',
        templateUrl: 'partials/login.html',
        controller: 'LoginController',
        controllerAs: 'vm',
        data: {
            requireLogin: false 
        }
    })   

    // State app
    .state('app', {
        abstract: true,
        views: {
            '': { template: '<div ui-view></div>'}
        },
        data: {
            requireLogin: true // this property will apply to all children of 'app'
        }
    })
    
    .state('app.dash', {
        url: '/dash',
        templateUrl: 'partials/dashboard.html'
    })
    
});


myModule.run(function ($state, $rootScope) {

    $rootScope.globals = $rootScope.globals || {};
    $rootScope.$on('$stateChangeStart', function (event, toState, toParams) {
        var requireLogin = toState.data.requireLogin;

        if (requireLogin && typeof $rootScope.globals.currentUser === 'undefined') {
        event.preventDefault();
        // get me a login modal!
        $state.go('login');
        }
    });
});


